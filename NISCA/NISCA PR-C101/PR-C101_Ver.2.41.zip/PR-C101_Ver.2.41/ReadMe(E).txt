===============================================================================
  PR-C101 PrinterDriver
                                                                     2013.09.10
===============================================================================

 --Contents-----------------------------------------------------
    1. Standard uninstallation procedure of the printer driver
    2. Troubleshooting
 ---------------------------------------------------------------


 1. Standard uninstallation procedure of the printer driver
 ---------------------------------------------------------------

  < Restrictions of the uninstallation >
    * Implement the uninstallation by the Administrator (a manager) authority.

  (1) Open "All programs" >> "Nisca" >>
      "PR-C101" >> "Uninstall" from the Start Menu.

  (2) Click "Next" on the initial screen of
      "Un-Installation for PR-C101 Printer" dialog window.

  (3) Confirm "Nisca PR-C101" is selected in the "Printer Model" window, and
      then click "Next" button.

  (4) Confirm "Nisca PR-C101" is listed as the "Printer Model" and
      "Printer Name", and then click "Start" button.

  (5) If the following dialog window is popped up after the start,
      select "Continue" and then click "Next" button.

  (6) Click "Finish" button.

  (7) Reboot the PC.


 2. Troubleshooting
 ----------------------------------------------

  (1) Printer driver installation procedure in case the installer was not
      launched automatically by insertion of the printer driver CD.

      The installer is not launched automatically on a several PC. On that case,
      the installer can be launched directly from the "Setup.exe"
      in the printer driver CD.

      < Restrictions of the installation >
        * Implement the installation by the Administrator (a manager) authority.
        * Do not connect I/F cable to PC until you are prompted during
          the driver installation.

      1) Insert the printer driver CD into the CD / DVD drive of the PC.

      2) Launch "My Computer" or "Explorer" and go to a CD / DVD drive
         recognizing the printer driver CD.

      3) Open the printer driver CD, and then double-click "Setup.exe"
         to launch the installer.

      4) Install the driver with reference to a printer bundled
         "Easy Setup Guide".

  (2) Printer driver uninstallation procedure in case the uninstallation icon
      in the Start Menu has disappeared

      In case the uninstallation icon has disappeared from the Start Menu,
      please uninstall the driver by using the printer driver CD.

      < Restrictions of the uninstallation >
        * Implement the uninstallation by the Administrator (a manager)
          authority.

      1) Insert the printer driver CD in the CD / DVD drive of the PC.

      2) Launch "My Computer" or "Explorer" and go to a CD / DVD drive
         recognizing the printer driver CD.

      3) Open the printer driver CD, and then double-click "PrnDrvUins.exe"
         in a "English" folder to launch the uninstaller.

      4) Uninstall the driver with reference to the "Standard uninstallation
         procedure of the printer driver" in this document.

  (3) A solution in case the driver has been installed by "Find New Hardware";
      On this case, you need to reinstall the driver by using
      the printer driver CD.

      In case the printer driver has been installed by the "Find New Hardware",
      which is launched when the printer is connected to a PC, please uninstall
      the driver by the following procedure, and then install the driver from
      the printer driver CD.

      1) Open the "Fax and Printer" dialog window from the Start Menu
         in the desktop. (For Windows VISTA, open the "Control panel"
         dialog window from the Start Menu, and then move to "Printers").

      2) Right click in the "Fax and Printer" window (For Vista, "Printers")
         but not on the icon/file name so that drop down menu is opened,
         and then select "Server properties�c" to open
         "Print Server Properties" dialog window.

         For VISTA user:
          If you can not find the "Server Properties�c",
          please select "Run as administrator"
          in the drop down menu so that you can find the "Server Properties�c"

      3) Select the "Drivers" tab of the "Print Server Properties".
         The following is the sample screen shot of the
         "Print Server Properties.".

      4) Select "Nisca PR-C101" from the list of the installed printer drivers,
         and then click the "Remove" button.

         For VISTA user:
          Once you click the "Remove" button, "Remove Driver And Package"
          dialog window is opened.
          Select "Remove driver and driver package", and then click "OK" button.
          After that VISTA confirm the implementation of the remove driver,
          click "Yes" to remove.

      5) Reboot the PC and reinstall the driver by using the printer driver CD.

  (4) The contents of the status monitor are not updated after standby mode.

      If the PC goes into the standby mode during the failure status
      of the printer such as run out of the card, the status monitor
      would not be updated. On this case, please recover by the following
      procedure.

      1) Reinstall the USB cable. (Disconnect and then install.)

      2) Reboot the PC, if the failure status is not cleared
         by the reinstallation of the USB cable.

      Note: Please disable the standby mode of the PC,
            in case this failure occurs frequently.

